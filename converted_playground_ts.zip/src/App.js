import React from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import ChatSection from './ChatSection';
import './App.css';

const App = () => {
  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content">
        <Header />
        <ChatSection />
      </div>
    </div>
  );
};

export default App;
