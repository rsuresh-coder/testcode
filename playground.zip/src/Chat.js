import React, { useState } from 'react';
import './Chat.css';

const Chat = () => {
  const [model, setModel] = useState('gpt-4');
  const [userMessage, setUserMessage] = useState('');
  const [messages, setMessages] = useState([]);

  const handleSendMessage = () => {
    if (userMessage.trim() !== '') {
      setMessages([...messages, { text: userMessage, sender: 'user' }]);
      setUserMessage('');
    }
  };

  return (
    <div className="chat">
      {/* Header Section */}
      <div className="chat-header">
        <h2>Chat</h2>
        <div className="chat-buttons">
          <button>Save</button>
          <button>Compare</button>
          <button>Export</button>
        </div>
      </div>

      {/* Chat Dropdown */}
      <div className="chat-dropdown">
        <label htmlFor="model">Model:</label>
        <select id="model" value={model} onChange={(e) => setModel(e.target.value)}>
          <option value="gpt-4">gpt-4</option>
          <option value="gpt-3.5">gpt-3.5</option>
        </select>
      </div>

      {/* System Instructions Section */}
      <div className="system-instructions">
        <h3>System Instructions</h3>
        <textarea placeholder="Enter system instructions here..."></textarea>
      </div>

      {/* Chat Area */}
      <div className="chat-area">
        {messages.map((message, index) => (
          <div key={index} className={`message ${message.sender}`}>
            {message.text}
          </div>
        ))}
      </div>

      {/* Chat Input Section */}
      <div className="chat-input">
        <input 
          type="text" 
          value={userMessage} 
          onChange={(e) => setUserMessage(e.target.value)} 
          placeholder="Enter your message..." 
        />
        <button onClick={handleSendMessage}>Send</button>
      </div>
    </div>
  );
};

export default Chat;
