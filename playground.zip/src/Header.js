import React from 'react';
import './Header.css';
import { FiSettings } from 'react-icons/fi';

const Header = () => {
  return (
    <div className="header">
      <h2>test_project</h2>
      <div className="header-links">
        <a href="/">Playground</a>
        <a href="/">Dashboard</a>
        <a href="/">Docs</a>
        <a href="/">API Reference</a>
        <FiSettings className="settings-icon" />
      </div>
    </div>
  );
};

export default Header;
