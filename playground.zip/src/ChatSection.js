import React, { useState } from 'react';
import './ChatSection.css';

const ChatSection = () => {
  const [model, setModel] = useState('gpt-4');
  const [userMessage, setUserMessage] = useState('');
  const [messages, setMessages] = useState([]);

  const handleSendMessage = () => {
    if (userMessage.trim() !== '') {
      setMessages([...messages, { text: userMessage, sender: 'user' }]);
      setUserMessage('');
    }
  };

  return (
    <div className="chat-section">
      <div className="chat-header">
        <h2>Chat</h2>
        <div className="chat-buttons">
          <button>Save</button>
          <button>Export</button>
          <button>Code</button>
        </div>
      </div>
      <hr />

      {/* Left Side: Model Selection + Chat Input */}
      <div className="chat-content">
        <div className="chat-left">
          {/* Model Selection */}
          <div className="model-selection">
            <label>Model:</label>
            <select value={model} onChange={(e) => setModel(e.target.value)}>
              <option value="gpt-4">gpt-4</option>
              <option value="gpt-3.5">gpt-3.5</option>
            </select>
          </div>

          {/* System Instructions */}
          <div className="system-instructions">
            <h3>System Instructions</h3>
            <textarea
              className="instructions-text"
              placeholder="Enter system instructions here..."
              rows="1"
            ></textarea>
          </div>

          {/* Chat Area */}
          <div className="chat-area">
            {messages.map((message, index) => (
              <div key={index} className={`message ${message.sender}`}>
                {message.text}
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <div className="chat-input">
            <textarea
              className="input-text"
              value={userMessage}
              onChange={(e) => setUserMessage(e.target.value)}
              placeholder="Enter your message..."
              rows="1"
            />
            <button onClick={handleSendMessage}>Run</button>
          </div>
        </div>

        {/* Right Side: Configuration Panel */}
        <div className="chat-right">
          <h3>Temperature</h3>
          <input type="range" min="0" max="2" step="0.1" defaultValue="1" />
          <h3>Maximum Tokens</h3>
          <input type="number" defaultValue="2048" />
          <h3>Stop Sequences</h3>
          <input type="text" placeholder="Enter stop sequences" />
          <h3>Top P</h3>
          <input type="range" min="0" max="1" step="0.1" defaultValue="1" />
          <h3>Frequency Penalty</h3>
          <input type="range" min="0" max="2" step="0.1" defaultValue="0" />
          <h3>Presence Penalty</h3>
          <input type="range" min="0" max="2" step="0.1" defaultValue="0" />
        </div>
      </div>
    </div>
  );
};

export default ChatSection;
