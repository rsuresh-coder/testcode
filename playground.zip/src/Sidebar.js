import React, { useState } from 'react';
import './Sidebar.css';
import { FiChevronLeft } from 'react-icons/fi';

const Sidebar = () => {
  const [minimized, setMinimized] = useState(false);

  return (
    <div className={`sidebar ${minimized ? 'minimized' : ''}`}>
      <div className="sidebar-header">
        <h3>Playground</h3>
        <button onClick={() => setMinimized(!minimized)}>
          <FiChevronLeft />
        </button>
      </div>
      <ul>
        <li>Chat</li>
        <li>Assistants</li>
      </ul>
    </div>
  );
};

export default Sidebar;
